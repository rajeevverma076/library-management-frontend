const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors')
const connectDB = require('./db/db.js');
const userRoutes = require('./routes/user');
const bookRoutes = require('./routes/book');
const app = express();
 

//Connect to the database
connectDB();

// Middleware
app.use(cors())
app.use(bodyParser.json());

// Connect to MongoDB
//mongoose.connect('mongodb://localhost:27017/library', { useNewUrlParser: true, useUnifiedTopology: true });
 
// Routes
app.use('/api/users', userRoutes)

app.use('/api/books', bookRoutes)
// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));