const Book = require('../models/Book');
//const User = require('../models/User');

//Get all books
const getBooks = (async(req, res) => {
   try{
const books=await Book.find();
res.json({
    message:"All Book List",
    data:books
})
   } catch(error){
    res.status(500).json({
        message:error.message
    })
   }
})

// Add a new book
const createBook = (async(req, res) => {
    const books=new Book({
        title:req.body.title,
        author:req.body.author,
        copies:req.body.copies,
     })
    try{
 const newBook=await books.save();
 res.status(201).json({
     message:"New book added",
     data:newBook
 })
    } catch(error){
     res.status(500).json({
         message:error.message
     })
    }
 })



module.exports = {
    getBooks,
    createBook
}