const mongoose = require("mongoose");
const Book = require("../models/Book");
const User = require("../models/User");

//Get all user
const getUsers = async (req, res) => {
    try {
        const books = await User.find();
        res.json({
            message: "All user list",
            data: books,
        });
    } catch (error) {
        res.status(500).json({
            message: error.message,
        });
    }
};

//Add new user
const createNewUser = async (req, res) => {
    const { name } = req.body;
    if (!name) {
        res.status(400).json({
            message: "Name is required",
        });
    }
    try {
        const newUser = new User({
            name,
            borrowedBooks: [],
        });
        console.log(newUser);
        await newUser.save();
        res.json({
            message: "User created successfully",
            data: newUser,
        });
    } catch (error) {
        res.status(500).json({
            message: error.message,
        });
    }
};

// Borrow a book
const borrowBook = async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        if (user.borrowedBooks.length >= 2) {
            return res.status(400).json({ message: "Borrowing limit reached" });
        }

        const book = await Book.findById(req.params.bookId);
        if (!book) {
            return res.status(404).json({ message: "Book not found" });
        }

        const alreadyBorrowed = user.borrowedBooks.find((b) => b.equals(book._id));
        if (alreadyBorrowed) {
            return res
                .status(400)
                .json({ message: "Book already borrowed by this user" });
        }

        user.borrowedBooks.push(book);
        await user.save();

        if (book.copies > 1) {
            book.copies -= 1;
            await book.save();
        } else {
            // await book.deleteOne();
        }

        res.status(200).json({ message: "Book borrowed successfully", user });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Return a book
const returnBook = async (req, res) => {
    const { userId, bookId } = req.params;
    const user = await User.findById(
        mongoose.Types.ObjectId.createFromHexString(userId)
    );
    if (!user) {
        return res.status(404).json({ message: "User not found" });
    }
    const book = await Book.findById(
        mongoose.Types.ObjectId.createFromHexString(bookId)
    );
    if (!book) {
        return res.status(404).json({ message: "Book not found" });
    }
    user.borrowedBooks.pull(book._id);
    book.copies += 1;
    await user.save();
    await book.save();
    res.json({ message: "Book returned", data: book });
};

const borrowedBooks = async (req, res) => {
    try {
        const books = await User.findById(mongoose.Types.ObjectId.createFromHexString(req.params.userId)).populate('borrowedBooks');
       console.log(books)
        res.json({
            message: "All user list",
            data: books,
        });
    } catch (error) {
        res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    getUsers,
    createNewUser,
    borrowBook,
    returnBook,
    borrowedBooks,
};
