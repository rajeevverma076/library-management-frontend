const request = require('supertest');

const mongoose = require('mongoose');
const app = require('../app');
const db = require('./db');
const User = require('../models/User');
const Book = require('../models/Book');
// Setup connection to the database
beforeAll(async () => await db.connect());
beforeEach(async () => await db.clear());
afterAll(async () => await db.close());
 
afterEach(async () => {
  await User.deleteMany();
  await Book.deleteMany();
});
 

 
describe('Users API', () => {

    test('two plus two is four', () => {
        expect(2 + 2).toBe(4);
      });

  test('POST /api/users/:userId/borrow/:bookId should borrow a book', async () => {
    const user = new User({ name: 'Test User', borrowedBooks: [] });
    await user.save();
 
    const book = new Book({ title: 'Test Book', author: 'Test Author', copies: 1 });
    await book.save();
 
    const response = await request(app)
      .post(`/api/users/${user._id}/borrow/${book._id}`);
    expect(response.status).toBe(200);
    expect(response.body.user.borrowedBooks).toHaveLength(1);
    expect(response.body.user.borrowedBooks[0].title).toBe('Test Book');
 
    const updatedBook = await Book.findById(book._id);
    expect(updatedBook).toBeNull();
  });
 
  test('POST /api/users/:userId/borrow/:bookId should not borrow a book if limit reached', async () => {
    const user = new User({ name: 'Test User', borrowedBooks: [new mongoose.Types.ObjectId(), new mongoose.Types.ObjectId()] });
    await user.save();
 
    const book = new Book({ title: 'Test Book', author: 'Test Author', copies: 1 });
    await book.save();
  });


});