
const express =  require('express');
const router = express.Router();
const  { 
    getUsers,
    createNewUser,
    borrowBook,
    returnBook,
    borrowedBooks
} = require('../controllers/userController');

// Users 
router.get('/', getUsers);
router.post('/register', createNewUser);
router.post('/:userId/borrow/:bookId', borrowBook);
router.post('/:userId/return/:bookId', returnBook)
router.get('/:userId/borrowedBooks', borrowedBooks)



module.exports = router ;


