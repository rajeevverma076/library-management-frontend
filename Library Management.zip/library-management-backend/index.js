// index.js
const express = require('express');
const mongoose = require('mongoose');
const Book = require('./models/Book');
const User = require('./models/User');
 
const app = express();
app.use(express.json());
 
mongoose.connect('mongodb://localhost:27017/library', { useNewUrlParser: true, useUnifiedTopology: true })
then(()=>console.log("MongoDB Connected"))
.catch(err=>console.error("MongoDB connection error",err));
 
// Get all books
app.get('/books', async (req, res) => {
  const books = await Book.find();
  res.json(books);
});
 
// Borrow a book
app.post('/users/:userId/borrow/:bookId', async (req, res) => {
  const { userId, bookId } = req.params;
  const user = await User.findById(userId);
  const book = await Book.findById(bookId);
 
  if (user.borrowedBooks.length >= 2) {
    return res.status(400).send('Borrowing limit exceeded');
  }
 
  if (book.copies > 0) {
    book.copies -= 1;
    user.borrowedBooks.push(book._id);
    await book.save();
    await user.save();
    res.send('Book borrowed');
  } else {
    res.status(400).send('No copies left');
  }
});
 
// Return a book
app.post('/users/:userId/return/:bookId', async (req, res) => {
  const { userId, bookId } = req.params;
  const user = await User.findById(userId);
  const book = await Book.findById(bookId);
 
  user.borrowedBooks.pull(book._id);
  book.copies += 1;
  await user.save();
  await book.save();
  res.send('Book returned');
});
 
app.listen(3000, () => {
  console.log('Server running on port 3000');
});
 


// server/routes/users.js
const express = require('express');
const router = express.Router();
const User = require('../models/user');
const Book = require('../models/book');
 
router.post('/:userId/borrow/:bookId', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
 
    if (user.borrowedBooks.length >= 2) {
      return res.status(400).json({ message: 'Borrowing limit reached' });
    }
 
    const book = await Book.findById(req.params.bookId);
    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }
 
    const alreadyBorrowed = user.borrowedBooks.find(b => b.equals(book._id));
    if (alreadyBorrowed) {
      return res.status(400).json({ message: 'Book already borrowed by this user' });
    }
 
    user.borrowedBooks.push(book);
    await user.save();
 
    if (book.copies > 1) {
      book.copies -= 1;
      await book.save();
    } else {
      await book.remove();
    }
 
    res.status(200).json({ message: 'Book borrowed successfully', user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
 
module.exports = router;
